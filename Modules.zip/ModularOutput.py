from ModularInput import number_one
from ModularInput import number_two
from ModularInput import calc_choice
from ModularProcess import calc_outcome

file = open("ModularProcess.py", "a+")

print("the answer is", calc_outcome)

file.close()

file2 = open("Calculations.txt", "a+")

with open("Calculations.txt", "a+"):
    file.write("number one = ", + f"{number_one}/n")
    file.write("number two = ", + f"{number_two}/n")
    file.write("type of operations = ", + f"{calc_choice}/n")
    file.write("outcome of the operation = ", f"{calc_outcome}/n"
file2.close
