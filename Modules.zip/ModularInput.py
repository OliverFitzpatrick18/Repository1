number_one = int(input("enter a number here = "))
number_two = int(input("enter another number here = "))

calc_type = {"+": "+ = Addition number's together",
             "-": "- = Difference between the numbers",
             "*": "* = the product of the numbers (Multiplication)",
             "/": "/ = the quotent of the numbers (divition)"}

for key, value in calc_type.items():
    print(f"{key}: {value}")


calc_choice = input("what operator do you want to do = ")


