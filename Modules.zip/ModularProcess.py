from ModularInput import number_one
from ModularInput import number_two
from ModularInput import calc_choice

file1 = open("ModularInput.py", "a+")

if calc_choice == "+":
    calc_outcome = number_one + number_two
elif calc_choice == "-":
    if number_one > number_two:
        calc_outcome = number_one - number_two
    elif number_one < number_two:
        calc_outcome = number_two - number_one
elif calc_choice == "*":
    calc_outcome = number_one * number_two
elif calc_choice == "/":
    calc_outcome = number_one / number_two

file1.close()


